package com.atguigu.chapter10

object Test02 {
  def main(args: Array[String]): Unit = {

  }
}
