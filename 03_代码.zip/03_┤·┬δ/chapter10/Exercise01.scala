package com.atguigu.chapter10

object Exercise01 {
  def main(args: Array[String]): Unit = {
    val list1 = List(1, 2, 3, "abc")
    //val list5 = 4 :: 5 :: 6 ::: list1 ::: Nil
    //println(list5)
  }
}
