package com.atguigu.chapter01.vars

object VarDemo03 {
  var name = "hello"
  val age = 100
  def main(args: Array[String]): Unit = {
    println("ok")

  }
}


