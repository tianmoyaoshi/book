package com.atguigu.chapter01

object Comment {
  def main(args: Array[String]): Unit = {
    println("hello,world!")
  }

  //tab 或者是 tab+shift
  /**
    * @deprecated 过期
    * @example
    * 输入n1 = 10 n2 = 20 return 30
    * @param n1
    * @param n2
    * @return 和
    */
  def sum(n1: Int, n2: Int): Int = {

    var str = "hell0" + "hell0"+ "hell0"+ "hell0"+ "hell0"+ "hell0"+ "hell0"+ "hell0"+ "hell0"+ "hell0"+ "hell0"+ "hell0"+ "hell0"+ "hell0"+ "hell0"
    return n1 + n2

  }
}
