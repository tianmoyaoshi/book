package com.atguigu.chapter17.abstractfactory.pizzastore.order

class SalePizza {
  //客户，来一个胡椒pizza
}
