package com.atguigu.chapter17.simplefactory

class Test {

}
