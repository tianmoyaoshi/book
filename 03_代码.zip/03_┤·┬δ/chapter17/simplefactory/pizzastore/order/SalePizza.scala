package com.atguigu.chapter17.simplefactory.pizzastore.order

class SalePizza {
  //客户，来一个胡椒pizza
}
