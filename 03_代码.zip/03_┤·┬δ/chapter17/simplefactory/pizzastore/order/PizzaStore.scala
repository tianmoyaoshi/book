package com.atguigu.chapter17.simplefactory.pizzastore.order

object PizzaStore {
  def main(args: Array[String]): Unit = {
    new OrderPizza
  }
}
