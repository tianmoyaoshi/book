package com.atguigu.chapter17.observer

class Test {

}
