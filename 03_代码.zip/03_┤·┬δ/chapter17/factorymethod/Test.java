package com.atguigu.chapter17.factorymethod;

public class Test {
}
