package com.atguigu.chapter17.factorymethod.pizzastore.order

object PizzaStore {
  def main(args: Array[String]): Unit = {
    new BJOrderPizza
  }
}
