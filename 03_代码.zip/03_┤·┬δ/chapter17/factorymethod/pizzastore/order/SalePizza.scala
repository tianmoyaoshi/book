package com.atguigu.chapter17.factorymethod.pizzastore.order

class SalePizza {
  //客户，来一个胡椒pizza
}
