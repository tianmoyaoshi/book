package com.atguigu.chapter17

class Test {
  def main(args: Array[String]): Unit = {
    //java.lang.Runtime
  }
}
