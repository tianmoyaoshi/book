package com.atguigu.chapter17.dyn

object MainTest {
  def main(args: Array[String]): Unit = {
    var mMatchService: MatchService = new MatchService()
  }
}
