package com.atguigu.chapter17.decorator.coffeebar.mycoffee

class ShortBlack extends Coffee {
  //使用主构造器
  super.setDescription("ShortBlack")
  super.setPrice(4.0f)
}
