package com.atguigu.chapter17.decorator.coffeebar.mycoffee

class DeCaf extends Coffee {

  //使用主构造器
  super.setDescription("DeCaf")
  super.setPrice(3.0f)
}
