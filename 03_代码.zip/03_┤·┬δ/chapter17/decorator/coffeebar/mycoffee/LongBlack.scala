package com.atguigu.chapter17.decorator.coffeebar.mycoffee

class LongBlack extends Coffee {
  //使用主构造器
  super.setDescription("LongBlack")
  super.setPrice(5.0f)
}
