package com.atguigu.chapter17.remotecandymachine

class Test {

}
