package com.atguigu.chapter08

object TestChildGame {
  def main(args: Array[String]): Unit = {
    /**
      *
      */
    //传统方法...不好，怎么办?=>静态概念
    //创建很多小孩，加入游戏
    //定义一个变量 totalNum ...
    var totalNum = 0

  }
}

class Child {

}
