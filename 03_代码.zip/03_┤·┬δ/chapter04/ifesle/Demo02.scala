package com.atguigu.chapter04.ifesle

object Demo02 {
  def main(args: Array[String]): Unit = {

    val age = 6
    if (age > 18) {
      println("age > 18")
    } else {
      println("age <= 18")
    }
  }
}
