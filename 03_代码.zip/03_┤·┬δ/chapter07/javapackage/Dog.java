package com.atguigu.chapter07.javapackage;



public class Dog {
    public static void main(String[] args) {
        System.out.println("hello dog");
    }
}
