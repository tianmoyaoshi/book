package com.atguigu.chapter07.javapackage.xm;

public class Tiger {
}
