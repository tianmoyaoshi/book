package com.atguigu.chapter07.homework

object Exercise05 {
  def main(args: Array[String]): Unit = {
      println("xx")
  }
}

class Monster{
  var age:Int = 1
  private var name:String = ""
  protected var sal:Double = 0.01

}
