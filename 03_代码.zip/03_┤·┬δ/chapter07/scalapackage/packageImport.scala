package com.atguigu.chapter07.scalapackage

//在scala中 java.lang.包  scala包  , Predef包



object packageImport {
  def main(args: Array[String]): Unit = {
  }
}
