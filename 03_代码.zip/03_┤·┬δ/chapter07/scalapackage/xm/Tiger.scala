package com.atguigu.chapter07.scalapackage.xm

class Tiger {

}
