package com.atguigu.chapter07.scalapackage.xh

class Tiger {

}
