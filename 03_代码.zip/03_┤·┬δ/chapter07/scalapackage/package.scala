package com.atguigu.chapter07

package object scalapackage {

}
