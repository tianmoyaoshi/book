package com.atguigu.chapter07

class Test {

}

object Test{

}
