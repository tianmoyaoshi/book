package com.atguigu.chapter12.casepak

object TestClass {

}

//class AAA extends  Item