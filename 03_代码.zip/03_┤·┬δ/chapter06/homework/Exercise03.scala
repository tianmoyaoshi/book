package com.atguigu.chapter06.homework

object Exercise03 {
  def main(args: Array[String]): Unit = {

    //定义List集合
    val list = List(1, 2, 3)
    println(list.reverse) //(3,2,1)
    println((1 to 10).reverse) //

  }
}
