package com.atguigu.chapter06.homework

object Exercise01 {
  def main(args: Array[String]): Unit = {

    val t = {} //
    println("t=" + t + " " + t.isInstanceOf[Unit]) // ()
  }
}
